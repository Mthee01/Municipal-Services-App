import { useQuery } from "@tanstack/react-query";
import { MapPin, Clock, FileText, AlertTriangle, Navigation, Eye, User, ChevronDown } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';

interface TechnicianLocation {
  id: number;
  technicianId: number;
  latitude: string;
  longitude: string;
  address?: string;
  isOnSite?: boolean;
  currentIssueId?: number;
  speed?: number;
  heading?: number;
  accuracy?: number;
  timestamp: string;
}

interface Technician {
  id: number;
  name: string;
  phone: string;
  email?: string;
  department: string;
  skills: string[];
  status: string;
  currentLocation?: string;
  latitude?: string;
  longitude?: string;
  teamId?: number;
  performanceRating: number;
  completedIssues: number;
  avgResolutionTime: number;
  lastUpdate: string;
  location?: TechnicianLocation;
}

export function TechnicianLocationTracker() {
  const [selectedTechnician, setSelectedTechnician] = useState<Technician | null>(null);
  
  // Get all technicians with their current locations
  const { data: techniciansWithLocations = [], isLoading: techniciansLoading, error } = useQuery<Technician[]>({
    queryKey: ["/api/technicians-with-locations"],
    refetchInterval: 10000, // Refetch every 10 seconds for real-time tracking
    refetchOnWindowFocus: true,
    refetchOnMount: true,
    staleTime: 5000, // Consider data stale after 5 seconds
  });

  // Calculate tracking enabled/disabled counts
  const enabledCount = techniciansWithLocations.filter(tech => 
    tech.location?.timestamp && 
    new Date(tech.location.timestamp).getTime() > Date.now() - 30 * 60 * 1000
  ).length;
  
  const totalCount = techniciansWithLocations.length;

  const formatTimeAgo = (timestamp: string) => {
    const now = Date.now();
    const updateTime = new Date(timestamp).getTime();
    const diffMinutes = Math.floor((now - updateTime) / (1000 * 60));
    
    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return new Date(timestamp).toLocaleDateString();
  };

  if (error) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <MapPin className="h-6 w-6 text-orange-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Technician Location Tracking</h2>
              <p className="text-sm text-gray-600">Monitor field staff GPS tracking status</p>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex items-center justify-center py-8">
            <AlertTriangle className="h-8 w-8 text-red-500 mr-2" />
            <span className="text-red-600">Failed to load technician tracking status</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="h-6 w-6 text-orange-600" />
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Technician Location Tracking</h2>
                <p className="text-sm text-gray-600">Monitor field staff GPS tracking status</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">{enabledCount} enabled</span>
              </div>
              <span className="text-sm text-gray-500">Updates every 10s</span>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          {techniciansLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
              <span className="ml-2 text-gray-600">Loading technicians...</span>
            </div>
          ) : (
            <div className="max-w-md">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Technician to View Location
              </label>
              <Select onValueChange={(value) => {
                const technician = techniciansWithLocations.find(t => t.id.toString() === value);
                if (technician) setSelectedTechnician(technician);
              }}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Choose a technician..." />
                </SelectTrigger>
                <SelectContent>
                  {techniciansWithLocations.map((technician) => {
                    const isTracking = technician.location?.timestamp && 
                      new Date(technician.location.timestamp).getTime() > Date.now() - 30 * 60 * 1000;
                    
                    return (
                      <SelectItem key={technician.id} value={technician.id.toString()}>
                        <div className="flex items-center justify-between w-full">
                          <span>{technician.name}</span>
                          <div className="flex items-center gap-2 ml-4">
                            <div className={`w-2 h-2 rounded-full ${isTracking ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                            <span className="text-xs text-gray-500">
                              {isTracking ? 'Tracking' : 'Offline'}
                            </span>
                          </div>
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              
              {techniciansWithLocations.length === 0 && (
                <p className="text-center text-gray-500 mt-4">No technicians available</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Detailed Location Modal */}
      <Dialog open={!!selectedTechnician} onOpenChange={() => setSelectedTechnician(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-orange-600" />
              {selectedTechnician?.name} - Location Tracking
            </DialogTitle>
          </DialogHeader>
          
          {selectedTechnician && (
            <div className="space-y-6">
              {/* Map Container */}
              {selectedTechnician.location && selectedTechnician.location.latitude && selectedTechnician.location.longitude && (
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white p-4">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <MapPin className="h-8 w-8" />
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">Live Location Tracking</h3>
                        <p className="text-orange-100 text-sm">Real-time GPS coordinates</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Coordinates Display */}
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">Coordinates</label>
                          <div className="mt-1 p-3 bg-white rounded-lg border">
                            <div className="font-mono text-sm">
                              <div>Lat: {parseFloat(selectedTechnician.location.latitude).toFixed(6)}</div>
                              <div>Lng: {parseFloat(selectedTechnician.location.longitude).toFixed(6)}</div>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium text-gray-700">Address</label>
                          <div className="mt-1 p-3 bg-white rounded-lg border">
                            <p className="text-sm text-gray-900">
                              {selectedTechnician.location.address || 'Address resolving...'}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Status Information */}
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">Accuracy</label>
                          <div className="mt-1 p-3 bg-white rounded-lg border">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${
                                selectedTechnician.location.accuracy && parseInt(selectedTechnician.location.accuracy.toString()) < 50 
                                  ? 'bg-green-500' 
                                  : parseInt(selectedTechnician.location.accuracy?.toString() || '999') < 100 
                                    ? 'bg-yellow-500' 
                                    : 'bg-red-500'
                              }`}></div>
                              <span className="text-sm">±{selectedTechnician.location.accuracy || 'N/A'} meters</span>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium text-gray-700">Last Update</label>
                          <div className="mt-1 p-3 bg-white rounded-lg border">
                            <p className="text-sm text-gray-900">
                              {formatTimeAgo(selectedTechnician.location.timestamp)}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Map Action Button */}
                    <div className="mt-6 flex gap-3">
                      <Button 
                        onClick={() => {
                          const url = `https://www.google.com/maps?q=${selectedTechnician.location?.latitude},${selectedTechnician.location?.longitude}`;
                          window.open(url, '_blank');
                        }}
                        className="flex-1"
                      >
                        <Navigation className="h-4 w-4 mr-2" />
                        View on Google Maps
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => {
                          const coords = `${selectedTechnician.location?.latitude},${selectedTechnician.location?.longitude}`;
                          navigator.clipboard?.writeText(coords);
                        }}
                        className="px-4"
                      >
                        Copy Coordinates
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Technician Information */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="text-center">
                  <label className="text-sm font-medium text-gray-700">Department</label>
                  <p className="text-gray-900 font-semibold">{selectedTechnician.department}</p>
                </div>
                <div className="text-center">
                  <label className="text-sm font-medium text-gray-700">Status</label>
                  <div className="mt-1">
                    <Badge variant="outline" className={
                      selectedTechnician.status === 'available' ? 'border-green-200 text-green-700' :
                      selectedTechnician.status === 'on_job' ? 'border-blue-200 text-blue-700' :
                      'border-gray-200 text-gray-700'
                    }>
                      {selectedTechnician.status === 'on_job' ? 'On Job' : 
                       selectedTechnician.status === 'available' ? 'Available' : 
                       selectedTechnician.status}
                    </Badge>
                  </div>
                </div>
                <div className="text-center">
                  <label className="text-sm font-medium text-gray-700">GPS Tracking</label>
                  <div className="mt-1">
                    <Badge variant={selectedTechnician.location?.timestamp && 
                      new Date(selectedTechnician.location.timestamp).getTime() > Date.now() - 30 * 60 * 1000 ? 
                      "default" : "secondary"} className={
                      selectedTechnician.location?.timestamp && 
                      new Date(selectedTechnician.location.timestamp).getTime() > Date.now() - 30 * 60 * 1000 ? 
                      "bg-green-100 text-green-800" : "bg-gray-100 text-gray-600"
                    }>
                      {selectedTechnician.location?.timestamp && 
                       new Date(selectedTechnician.location.timestamp).getTime() > Date.now() - 30 * 60 * 1000 ? 
                       "Enabled" : "Disabled"}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* No Location Available State */}
              {!selectedTechnician.location && (
                <div className="text-center py-12">
                  <MapPin className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Location Data Available</h3>
                  <p className="text-gray-500 text-sm">GPS tracking is disabled or no recent location updates received</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}