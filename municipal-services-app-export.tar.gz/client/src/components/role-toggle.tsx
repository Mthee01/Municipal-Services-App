import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { User, Shield, Building2, MapPin, Wrench, UserCheck } from "lucide-react";
import type { UserRole } from "@/lib/types";

interface RoleToggleProps {
  currentRole: UserRole | null;
  onRoleChange: (role: UserRole) => void;
}

const roleConfig: Record<UserRole, { label: string; icon: any; color: string; description: string }> = {
  citizen: {
    label: "Citizen",
    icon: User,
    color: "bg-blue-50 text-blue-700 border-blue-200",
    description: "Report issues and track services"
  },
  call_centre_agent: {
    label: "Call Centre Agent",
    icon: UserCheck,
    color: "bg-green-50 text-green-700 border-green-200",
    description: "Handle calls and manage citizen requests"
  },
  admin: {
    label: "Administrator",
    icon: Shield,
    color: "bg-purple-50 text-purple-700 border-purple-200",
    description: "Full system administration"
  },
  mayor: {
    label: "Mayor",
    icon: Building2,
    color: "bg-red-50 text-red-700 border-red-200",
    description: "Municipality-wide oversight"
  },
  ward_councillor: {
    label: "Ward Councillor",
    icon: MapPin,
    color: "bg-orange-50 text-orange-700 border-orange-200",
    description: "Ward-specific management"
  },
  tech_manager: {
    label: "Technical Manager",
    icon: Wrench,
    color: "bg-indigo-50 text-indigo-700 border-indigo-200",
    description: "Technician allocation and performance"
  },
  field_technician: {
    label: "Field Technician",
    icon: Wrench,
    color: "bg-cyan-50 text-cyan-700 border-cyan-200",
    description: "On-site repairs and maintenance work"
  }
};

interface RoleToggleWithUserProps extends RoleToggleProps {
  username?: string;
}

export function RoleToggle({ currentRole, onRoleChange, username }: RoleToggleWithUserProps) {
  if (!currentRole) {
    return null;
  }

  const currentConfig = roleConfig[currentRole];
  const Icon = currentConfig.icon;

  return (
    <div className="flex items-center gap-3">
      <Badge variant="outline" className={currentConfig.color}>
        <Icon className="w-4 h-4 mr-1" />
        {currentConfig.label}{username && ` - ${username}`}
      </Badge>
      
      <Select value={currentRole} onValueChange={onRoleChange}>
        <SelectTrigger className="w-48">
          <SelectValue placeholder="Switch role" />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(roleConfig).map(([role, config]) => {
            const RoleIcon = config.icon;
            return (
              <SelectItem key={role} value={role}>
                <div className="flex items-center gap-2">
                  <RoleIcon className="w-4 h-4" />
                  <div>
                    <div className="font-medium">{config.label}</div>
                    <div className="text-xs text-gray-500">{config.description}</div>
                  </div>
                </div>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
    </div>
  );
}
